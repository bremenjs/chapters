(function(window) {

	var url = 'https://ajax.googleapis.com/ajax/services/search/news?v=1.0&q=javascript';
	var listNode = document.getElementById('list');
	var loadIndicatorNode = document.getElementById('load-indicator');

	// Send a request to background.js
	chrome.extension.sendRequest({type: 'load', url: url}, function(responseData) {
		// Parse JSON data
		var data = JSON.parse(responseData);
		// Export the response for debugging purposes
		window.data = data;

		// Add an item to the list
		var articles = data.responseData.results;
		articles.forEach(function(article) {
			addListElement(article.titleNoFormatting);
		});

		// Hide load indicator
		loadIndicatorNode.style.display = 'none';
	});

	// Adds an item to the list
	function addListElement(text) {
		var itemNode = document.createElement('li');
		//var textNode = document.createTextNode(text);
		//itemNode.appendChild(textNode);
		itemNode.innerHTML = text; // Dangerous because of XSS
		listNode.appendChild(itemNode);
	}

})(window, undefined);