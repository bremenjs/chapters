// Listens for requests (in this case from popup.html)
chrome.extension.onRequest.addListener(function(request, sender, callback) {
	if (request.type === 'load') {
		// A resource load was requested
		load(request.url, callback);
	}
});





// Load something
function load(url, callback) {
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function readyStateChange() {
		// Done
		if (xhr.readyState === 4) {
			callback(xhr.response);
		}
	};
	xhr.open("GET", url, true);
	xhr.send();
}